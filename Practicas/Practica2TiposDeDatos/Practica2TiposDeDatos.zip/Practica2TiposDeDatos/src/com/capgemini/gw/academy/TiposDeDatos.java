/**
 * 
 */
package com.capgemini.gw.academy;

/**
 * @author rosasanc
 *
 */
public class TiposDeDatos {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double distancia = 0;
		int sonido = 340;
		double tiempo = 7.2;
		
		distancia = sonido*tiempo;
		System.out.println("La distancia es: " + distancia + " metros");
		
	}

}
