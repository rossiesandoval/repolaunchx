/**
 * 
 */
package com.capgemini.gw.academy;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * @author rosasanc
 *
 */
public class Practica4Ciclos {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner(System.in);
		boolean salir = false;
		int op;
		do
		{
		System.out.println("1.-If \n2.-Switch \n3.-While \n4.-Do while \n5.- Salir");
		op = scanner.nextInt();
		
		switch(op) {
		case 1: 
				System.out.println("if(op==0) { } else if (op!=0) { } ");
				break;
		case 2:
				System.out.println("case1: {} case2: {} case3: {} break;");
				break;
		case 3:
				System.out.println("while(){}");
				break;
			
		case 4:
				System.out.println("Do { }while()");
				break;
		case 5:
			salir = true;
			break;
		}
		
		}while(!salir);

		}
}