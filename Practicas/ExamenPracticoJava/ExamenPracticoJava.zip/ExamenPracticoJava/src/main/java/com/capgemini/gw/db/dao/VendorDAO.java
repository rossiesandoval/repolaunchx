package com.capgemini.gw.db.dao;

import java.io.IOException;

import com.capgemini.guideware.db.dao.CustomerDAO;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class VendorDAO extends HttpServlet {

	public VendorDAO() {
		// TODO Auto-generated constructor stub
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher dispatcher = req.getRequestDispatcher("AddCustomer.jsp");
		System.out.println(req.getServletPath());
		dispatcher.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
		
	}
	private void registrarP(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
		Vendor vendor = new Vendor(0, req.getParameter("id"), req.getParameter("nombre"), req.getParameter("rfc"), req.getParameter("activo"));
		VendorDAO.registrarP(vendor);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("index.jsp");
		dispatcher.forward(req, resp);
		
		
	}
	
	


}
