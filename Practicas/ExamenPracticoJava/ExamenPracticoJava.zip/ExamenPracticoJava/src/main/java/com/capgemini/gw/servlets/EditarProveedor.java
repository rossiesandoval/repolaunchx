package com.capgemini.gw.servlets;

import java.io.IOException;

import com.capgemini.guideware.db.dao.Customer;
import com.capgemini.guideware.db.dao.CustomerDAO;
import com.capgemini.gw.db.dao.Vendor;
import com.capgemini.gw.db.dao.VendorDAO;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class EditarProveedor extends HttpServlet {

	public EditarProveedor() {
		super();
	}
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = req.getParameter("name");
		VendorDAO dao= new VendorDAO();
		Vendor vendor = dao.searchCustomerByName(name);
		RequestDispatcher dispatcher = req.getRequestDispatcher("updateCustomer.jsp");
		req.setAttribute("Vendor", vendor);
		dispatcher.forward(req, resp);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String NombreAnterior = (String) req.getParameter("NombreAnterior");
		String name = (String) req.getParameter("nombre");
		System.out.println("Nombre anterior: " + NombreAnterior);
		System.out.println("Nombre: " + name);
		Vendor vendor = new Vendor();
		vendor.setName(name);
		VendorDAO dao = new VendorDAO();
		dao.EditarProveedor(NombreAnterior, vendor);
		RequestDispatcher dispatcher = req.getRequestDispatcher("Customers");
		dispatcher.forward(req, resp);
	}
	
	

}
