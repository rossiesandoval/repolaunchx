package com.capgemini.gw.servlets;

import java.io.IOException;
import java.util.List;


import com.capgemini.gw.db.dao.VendorDAO;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Vendor")
public class Vendor extends HttpServlet {

	public Vendor() {
		super();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		VendorDAO dao = new VendorDAO();
		List<Vendor> customers = dao.searchVendor();
		RequestDispatcher dispatcher = req.getRequestDispatcher("customers.jsp");
		req.setAttribute("Customers", customers);
		dispatcher.forward(req,  resp);
	}
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	doGet(req, resp);
}

}
