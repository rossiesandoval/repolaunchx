package com.capgemini.gw.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

	public DBConnection() {
	}
	
	public Connection getConnection() {
		Connection connection = null;
		
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://localhost::3306/tienda", "root", "root1234");
	}catch (Exception e) {
		e.printStackTrace();
	}
	return connection;
	
}

}
