package com.capgemini.gw.servlets;

import java.io.IOException;

import com.capgemini.guideware.db.dao.CustomerDAO;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Registrar")
public class RegistrarProveedor extends HttpServlet {

	public RegistrarProveedor() {
		super();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher dispatcher = req.getRequestDispatcher("AddCustomer.jsp");
		System.out.println(req.getServletPath());
		dispatcher.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String customer = (String) req.getAttribute("name");
		
		customer.setName(name);
		
		CustomerDAO dao = new CustomerDAO();
		dao.insert(customer);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("Customers");
		dispatcher.forward(req, resp);
		
	}


}
