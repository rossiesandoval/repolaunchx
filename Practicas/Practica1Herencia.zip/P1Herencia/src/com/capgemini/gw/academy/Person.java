/**
 * 
 */
package com.capgemini.gw.academy;

import java.util.Scanner;

/**
 * @author rosasanc
 *
 */
public class Person {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Name: ");
		String name = scanner.next();
		
		System.out.println("Last name: ");
		String lastname = scanner.next();
		
		System.out.println("Mother last name: ");
		String mlastname = scanner.next();
		
		System.out.println("Birth date: ");
		int birthdate = scanner.nextInt();
		
		System.out.println("Email: ");
		String email = scanner.next();
		
		
		
		
	}

}
