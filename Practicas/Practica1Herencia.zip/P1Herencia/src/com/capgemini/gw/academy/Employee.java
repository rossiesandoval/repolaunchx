/**
 * 
 */
package com.capgemini.gw.academy;

/**
 * @author rosasanc
 *
 */
public class Employee extends Person {
	int start_date = 0;
}
