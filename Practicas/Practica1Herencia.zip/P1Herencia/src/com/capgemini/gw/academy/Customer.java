/**
 * 
 */
package com.capgemini.gw.academy;

/**
 * @author rosasanc
 *
 */
public class Customer extends Person {
	
	char department;

}
