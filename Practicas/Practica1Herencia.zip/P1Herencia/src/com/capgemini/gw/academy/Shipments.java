/**
 * 
 */
package com.capgemini.gw.academy;

/**
 * @author rosasanc
 *
 */
public class Shipments {
	int shipment_id = 0;
	
	int shipment_date = 0;
	
	int employee_id = 0;
}
