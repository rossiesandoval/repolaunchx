/**
 * 
 */
package com.capgemini.gw.academy;

/**
 * @author rosasanc
 *
 */
public class Orders extends Customer {
	
	int order_id = 01;
	int order_date = 02012020;
	
}
 