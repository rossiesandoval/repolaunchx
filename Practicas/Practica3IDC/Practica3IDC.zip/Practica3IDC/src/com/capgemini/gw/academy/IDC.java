/**
 * 
 */
package com.capgemini.gw.academy;

import java.util.Scanner;

/**
 * @author rosasanc
 *
 */
public class IDC {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("1.-If \n2.-Switch \n3.-While \n4.-Do while");
		Scanner scanner = new Scanner(System.in);
		int op = scanner.nextInt();
		switch(op) {
		case 1: 
			if(op ==1)
			{
				System.out.print("if(op==0) { } else if (op!=0) { } ");
			}
		case 2:
			if(op==2)
			{
				System.out.println("case1: {} case2: {} case3: {} break;");
			}
		case 3:
			if(op==3)
			{
				System.out.println("while(){}");
			}
		case 4:
			if(op==4)
			{
				System.out.println("Do { }while()");
			}
		case 5:
			if(op>=5)
			{
				System.out.print("Invalid option");
			}
			break;
		}
		
		
	}	
	

}
